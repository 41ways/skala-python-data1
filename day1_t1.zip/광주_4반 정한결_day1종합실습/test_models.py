"""
════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════

머리말
[종합실습] pydantic 모델 검증 테스트
- 설명: WeatherHour / CountryInfo / IpInfo 세 모델이 정상 값은 통과시키고
        범위·타입을 벗어난 값은 ValidationError를 내는지 확인
- 실행환경: 버전 3.11 (코드는 3.9에서도 돌아가게 작성)
- 작성자: 정한결
- 변경내역:
        v1 모델 3종 정상/오류 케이스 테스트
        v2 오타 및 코드 수정
════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════
"""

import pytest
from pydantic import ValidationError

from models import WeatherHour, CountryInfo, IpInfo


# ══════════════════════════════════
# WeatherHour
# ══════════════════════════════════

def test_weather_hour_valid():
    """정상 범위 값이면 그냥 생성되는지 확인"""
    record = WeatherHour(time="2026-07-20T00:00", temperature_2m=23.2, precipitation_probability=50)
    assert record.temperature_2m == 23.2
    assert record.precipitation_probability == 50


def test_weather_hour_temperature_out_of_range():
    """기온이 60 초과면 ValidationError 나야 함 (ge=-50, le=60)"""
    with pytest.raises(ValidationError):
        WeatherHour(time="2026-07-20T00:00", temperature_2m=100.0, precipitation_probability=50)


def test_weather_hour_precipitation_out_of_range():
    """강수확률이 100 초과면 ValidationError 나야 함"""
    with pytest.raises(ValidationError):
        WeatherHour(time="2026-07-20T00:00", temperature_2m=20.0, precipitation_probability=150)


# ══════════════════════════════════
# CountryInfo
# ══════════════════════════════════

def test_country_info_valid():
    """정상 값이면 그냥 생성되는지 확인"""
    record = CountryInfo(
        name="Korea", capital="Seoul", region="Asia",
        population=51780579, currency_code="KRW", currency_name="South Korean won",
    )
    assert record.population == 51780579


def test_country_info_population_must_be_positive():
    """인구가 0 이하면 ValidationError 나야 함 (gt=0)"""
    with pytest.raises(ValidationError):
        CountryInfo(
            name="Korea", capital="Seoul", region="Asia",
            population=0, currency_code="KRW", currency_name="South Korean won",
        )


# ══════════════════════════════════
# IpInfo
# ══════════════════════════════════

def test_ip_info_valid():
    """정상 위ㄷ 경도면 그냥 생성되는지 확인"""
    record = IpInfo(
        query="8.8.8.8", country="United States", city="Ashburn",
        region_name="Virginia", isp="Google LLC", lat=39.03, lon=-77.5,
    )
    assert record.lat == 39.03


def test_ip_info_latitude_out_of_range():
    """위도가 90 초과면 ValidationError 나야 함 (field_validator에서 체크)"""
    with pytest.raises(ValidationError):
        IpInfo(
            query="8.8.8.8", country="US", city="Ashburn",
            region_name="Virginia", isp="Google LLC", lat=999.0, lon=-77.5,
        )