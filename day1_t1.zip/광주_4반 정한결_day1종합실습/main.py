"""
════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════

머리말
[종합실습] 데이터 수집 미니 파이프라인
- 설명: open-meteo(기상) / countries.dev(국가) / ip-api(IP 위치) 3개 api를
        asyncio.gather()로 동시 수집,pydantic 검증,csv,parquet 저장 및
        성능 비교까지 수행
- 실행환경: 버전 3.11 (코드는 3.9에서도 돌아가게 작성)
- 작성자: 정한결
- 변경내역:
        v1 비동기 수집 뼈대
        v2 pydantic 검증 단계 추가
        v3 csv,parquet 비교 추가
        v4 주석 보강
        v5 오류 데이터 (demo_error_handling) 추가
        v6 assert를 실제 결과에 맞는 정확한 값으로 수정,
           예외 원인(검증 실패,구조 오류) 구분해서 기록
        v7 코드 및 주석 수정

이슈 사항
    - 실측 결과 weather(72건)처럼 데이터가 적을 땐 parquet이 csv보다
      쓰기·읽기 모두 느리게 나옴. 수만 행 이상에서는 역전될 것으로 예상되나 이번
      실습 데이터 규모로는 검증하지 않음(아래 결과 참고).

    + 추가 초기 실행 시 pyarrow 로딩 비용이 섞여서 측정될 수 있음
      (실제로 재실행 시 parquet 쓰기가 0.93초 -> 0.03초로 단축됨)

    + 추가 실제 api 응답은 3개 다 정상이라 demo_error_handling()으로
      일부러 오류 데이터를 넣어서 확인함(아래 오류 처리 시연 결과 참고)

════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import time
from functools import wraps
from pathlib import Path

import httpx
import pandas as pd
from pydantic import ValidationError
from models import WeatherHour, CountryInfo, IpInfo

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# 3개 api 주소 (지문 PDF 65 참고)
WEATHER_URL = (
    "https://api.open-meteo.com/v1/forecast"
    "?latitude=37.5665&longitude=126.9780"
    "&hourly=temperature_2m,precipitation_probability"
    "&forecast_days=3&timezone=Asia/Seoul"
)
COUNTRY_URL = "https://countries.dev/alpha/KOR"
IP_URL = "http://ip-api.com/json/8.8.8.8"

OUTPUT_DIR = Path("output")


# 실습 2 @timer 재사용 — 함수 실행 시간 측정용
def timer(func):
    """함수 실행 시간을 찍어주는 데코레이터. async 함수를 감싸는 거라
    wrapper도 async로 만들고 await로 원래 함수를 호출해야 함"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        t = time.perf_counter()
        result = await func(*args, **kwargs)
        print(f"{func.__name__} 실행 시간: {time.perf_counter() - t:.4f}초")
        return result
    return wrapper


async def fetch_json(client, name, url):
    """api 하나를 호출해서 (이름,json) 튜플로 반환.
    여기서 실패를 잡아 None으로 돌려줌, 하나 실패로 gather()에 모은
    다른 두 요청이 같이 죽지 않게"""
    try:
        resp = await client.get(url, timeout=10)
        resp.raise_for_status()  # 4xx,5xx 응답이면 여기서 예외 발생
    except httpx.HTTPError as e:
        # 타임아웃, 연결 실패, 4xx,5xx 전부 여기로 옴
        logger.error(f"{name} 수집 실패: {e}")
        return name, None
    else:
        logger.info(f"{name} 수집 성공: {url}")
        return name, resp.json()


@timer
async def collect_all():
    """3개 api를 gather()로 동시에 호출. 순차로 하면 3번 왕복이지만
    동시에 보내면 제일 느린 것 하나만큼만 기다리면 됨 (PDF 63의 "100x" 원리)"""
    async with httpx.AsyncClient() as client:
        tasks = [
            fetch_json(client, "weather", WEATHER_URL),
            fetch_json(client, "country", COUNTRY_URL),
            fetch_json(client, "ip", IP_URL),
        ]
        results = await asyncio.gather(*tasks)
    return dict(results)  # {"weather": {...}, "country": {...}, "ip": {...}}


# ══════════════════════════════════
# pydantic 검증 — 원본 json을 모델 필드에 맞게 변환
# ══════════════════════════════════

def parse_weather(data):
    """open-meteo 응답에서 시간별 데이터를 WeatherHour 리스트로 변환.
    time,temperature_2m,precipitation_probability 세 배열이 같은 인덱스로
    대응되는 구조라 zip으로 한 줄씩 묶어서 모델에 넣음"""
    valid, errors = [], []
    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    temps = hourly.get("temperature_2m", [])
    precs = hourly.get("precipitation_probability", [])

    for i, (t, temp, prec) in enumerate(zip(times, temps, precs)):
        try:
            valid.append(WeatherHour(time=t, temperature_2m=temp, precipitation_probability=prec))
        except ValidationError as e:
            # 어느 row가 왜 틀렸는지 알 수 있게 인덱스와 함께 기록
            errors.append({"row": i, "reason": "validation", "error": str(e)})
    return valid, errors


def parse_country(data):
    """countries.dev 응답 하나를 CountryInfo로 변환.
    currencies가 리스트라서 첫 번째 것만 꺼내 평탄화함"""
    try:
        currency = data["currencies"][0]
    except (KeyError, IndexError) as e:
        # 응답 구조 자체가 예상과 다른 경우 (예: currencies 필드가 아예 없음)
        return [], [{"row": 0, "reason": "structure", "error": str(e)}]

    try:
        record = CountryInfo(
            name=data["name"],
            capital=data["capital"],
            region=data["region"],
            population=data["population"],
            currency_code=currency["code"],
            currency_name=currency["name"],
        )
    except (ValidationError, KeyError) as e:
        # 값은 있는데 검증 규칙을 어긴 경우(예: population<=0) 또는
        # name,capital 같은 필수 키가 응답에서 빠진 경우
        return [], [{"row": 0, "reason": "validation", "error": str(e)}]
    else:
        return [record], []


def parse_ip(data):
    """ip-api 응답 하나를 IpInfo로 변환.
    status가 success가 아니면 애초에 검증할 데이터가 아니니까
    pydantic 검증 이전에 먼저 걸러냄"""
    if data.get("status") != "success":
        return [], [{"row": 0, "reason": "structure", "error": f"api 응답 실패: status={data.get('status')}"}]
    try:
        record = IpInfo(
            query=data["query"],
            country=data["country"],
            city=data["city"],
            region_name=data["regionName"],
            isp=data["isp"],
            lat=data["lat"],
            lon=data["lon"],
        )
    except (ValidationError, KeyError) as e:
        return [], [{"row": 0, "reason": "validation", "error": str(e)}]
    else:
        return [record], []


# ══════════════════════════════════
# [배점 대응] 타입 오류 시 예외 처리 시연
# ══════════════════════════════════

def demo_error_handling():
    """실제 api 응답은 전부 정상이라 오류 검출 경로가 한 번도 안 도는데,
    일부러 잘못된 값을 섞어서 검증이 실제로 동작하는지 확인함.
    4행 중 row 1은 temperature=999(범위초과)와 precipitation=150(범위초과)이
    같은 행에 겹쳐 있어 필드 오류 2개가 한 번에 잡히고, row 2는 temperature="abc"
    (타입 자체가 틀림)로 별도 오류 1개가 잡혀서 오류 난 행은 총 2개가 정확한 값"""
    bad_hourly_data = {
        "hourly": {
            "time": ["2026-07-20T00:00", "2026-07-20T01:00", "2026-07-20T02:00", "2026-07-20T03:00"],
            "temperature_2m": [23.2, 999.0, "abc", 25.0],
            "precipitation_probability": [50, 150, 30, 40],
        }
    }
    valid, errors = parse_weather(bad_hourly_data)
    print("\n─── 오류 처리 시연 (일부러 잘못된 값 섞은 4건 중) ───")
    print(f"valid {len(valid)}건 / errors {len(errors)}건")
    for err in errors:
        print(f"  row {err['row']} ({err['reason']}): {err['error'][:100]}")
    assert len(valid) == 2  # row 0, row 3만 정상
    assert len(errors) == 2  # row 1(필드 오류 2개), row 2(타입 오류 1개), 오류 난 행은 2개
    print("오류 처리 검증 통과")


# ══════════════════════════════════
# 저장 + 성능 비교 (csv vs parquet)
# ══════════════════════════════════

def save_and_compare(name, records):
    """레코드 리스트를 csv,parquet 두 형식으로 저장하고 쓰기,읽기 시간,
    파일 크기를 측정해 출력함. 컬럼명은 모델 필드에서 그대로 가져와서
    스키마 바뀌어도 이 함수는 수정할 필요 없게끔"""
    if not records:
        print(f"{name}: 저장할 데이터 없음 (건너뜀)")
        return

    df = pd.DataFrame([r.model_dump() for r in records])
    csv_path = OUTPUT_DIR / f"{name}.csv"
    parquet_path = OUTPUT_DIR / f"{name}.parquet"

    t = time.perf_counter()
    df.to_csv(csv_path, index=False, encoding="utf-8")
    csv_write = time.perf_counter() - t

    t = time.perf_counter()
    df.to_parquet(parquet_path, index=False)
    parquet_write = time.perf_counter() - t

    t = time.perf_counter()
    pd.read_csv(csv_path)
    csv_read = time.perf_counter() - t

    t = time.perf_counter()
    pd.read_parquet(parquet_path)
    parquet_read = time.perf_counter() - t

    csv_size = csv_path.stat().st_size
    parquet_size = parquet_path.stat().st_size

    print(f"\n[{name}] {len(records)}건")
    print(f"  쓰기 - csv: {csv_write:.5f}초 / parquet: {parquet_write:.5f}초")
    print(f"  읽기 - csv: {csv_read:.5f}초 / parquet: {parquet_read:.5f}초")
    print(f"  크기 - csv: {csv_size}B / parquet: {parquet_size}B")


if __name__ == "__main__":
    OUTPUT_DIR.mkdir(exist_ok=True)

    raw = asyncio.run(collect_all())

    weather_valid, weather_errors = parse_weather(raw["weather"] or {})
    country_valid, country_errors = parse_country(raw["country"] or {})
    ip_valid, ip_errors = parse_ip(raw["ip"] or {})

    print("─── 검증 결과 ───")
    print(f"weather: valid {len(weather_valid)}건 / errors {len(weather_errors)}건")
    print(f"country: valid {len(country_valid)}건 / errors {len(country_errors)}건")
    print(f"ip     : valid {len(ip_valid)}건 / errors {len(ip_errors)}건")

    print("\n─── 저장 + 성능 비교 ───")
    save_and_compare("weather", weather_valid)
    save_and_compare("country", country_valid)
    save_and_compare("ip", ip_valid)

    demo_error_handling()