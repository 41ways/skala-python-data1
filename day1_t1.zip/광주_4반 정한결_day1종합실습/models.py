"""
════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════

머리말
[종합실습] 데이터 수집 미니 파이프라인 — pydantic 스키마 정의
- 설명: open-meteo(기상) / countries.dev(국가) / ip-api(IP 위치) 3개 api
        응답을 검증할 pydantic v2 모델 정의
- 실행환경: 버전 3.11 (코드는 3.9에서도 돌아가게 작성)
- 작성자: 정한결
- 변경내역:
        v1 모델 3종 정의
        v2 주석 보강 + str_strip_whitespace 적용
        v3 코드 및 주석 수정

이슈 사항 (지문 범위를 넘어서 의도적으로 구현하지 않은 것)
    - month,시각 형식까지는 검증하지 않음.
      지문이 요구한 건 "타입·범위"까지라 형식(pattern) 검증은 과제 범위 밖이라 판단해 제외함.
      Field(pattern=...)로 확장 가능.
    - currency, population처럼 국가마다 없을 수 있는 값은 고려하지 않음.(인구수 0과 같은)
      (대상이 한국 고정이라 과제 범위에선 항상 존재함)
    - 실습 1,2에서 다른분들이 공백 제거 코드를 쓰신 게 결측값 제거와 재사용성면에서
      더 완성도 있다고 판단하여 str_strip_whitespace 추가함.

════════════════════════════════════════════════════════════════════
════════════════════════════════════════════════════════════════════
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator


# ══════════════════════════════════
# open-meteo: 시간대별 기온·강수확률
# ══════════════════════════════════

class WeatherHour(BaseModel):
    """서울 시간대별 기상 데이터 한 행.
    -50~60도, 0~100%로 범위를 걸어서 api가 이상한 값을 주면 여기서 걸러짐"""

    # 문자열 필드는 공백만 들어와도 빈 값 취급하도록 전역 설정
    # (예: 응답이 "  " 처럼 공백만 온 경우까지 min_length=1에 걸리게 함)
    model_config = ConfigDict(str_strip_whitespace=True)

    time: str = Field(min_length=1)  # ISO8601 시각 문자열
    temperature_2m: float = Field(ge=-50, le=60)  # 서울 기준 상식 범위
    precipitation_probability: int = Field(ge=0, le=100)  # 확률이라 0~100 고정


# ══════════════════════════════════
# countries.dev: 국가 정보
# ══════════════════════════════════

class CountryInfo(BaseModel):
    """국가 정보 한 건. currencies는 api 응답에서 리스트로 오는데
    첫 번째 것만 꺼내 currency_code / currency_name으로 평탄화해서 받음
    (csv,parquet에 저장하려면 중첩 구조 대신 평평한 값이 필요해서)"""

    model_config = ConfigDict(str_strip_whitespace=True)

    name: str = Field(min_length=1)
    capital: str = Field(min_length=1)
    region: str = Field(min_length=1)
    population: int = Field(gt=0)  # 인구가 0이거나 음수면 이상 데이터
    currency_code: str = Field(min_length=1)
    currency_name: str = Field(min_length=1)


# ══════════════════════════════════
# ip-api: IP 기반 지역 정보
# ══════════════════════════════════

class IpInfo(BaseModel):
    """ip 조회 결과 한 건. status가 success인 응답만 여기로 들어온다는 전제
    (status 체크는 main.py의 parse_ip에서 검증 이전에 먼저 걸러냄)"""

    model_config = ConfigDict(str_strip_whitespace=True)

    query: str = Field(min_length=1)   # 조회한 ip 문자열
    country: str = Field(min_length=1)
    city: str = Field(min_length=1)
    region_name: str = Field(min_length=1)
    isp: str = Field(min_length=1)
    lat: float
    lon: float

    # 위도,경도는 gt,lt 두 조건이 세트라 field만으로는 에러 메시지를
    # 원하는 문구로 못 달아서 field_validator로 분리함
    @field_validator("lat")
    @classmethod
    def lat_range(cls, v):
        if not -90 <= v <= 90:
            raise ValueError("위도는 -90~90 범위여야 함")
        return v

    @field_validator("lon")
    @classmethod
    def lon_range(cls, v):
        if not -180 <= v <= 180:
            raise ValueError("경도는 -180~180 범위여야 함")
        return v